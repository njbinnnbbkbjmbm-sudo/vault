package com.hal.vault

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

val BG = Color.parseColor("#0F1419")
val CARD = Color.parseColor("#1B222B")
val BLUE = Color.parseColor("#2A7DE1")
val RED = Color.parseColor("#D64545")
val GREEN = Color.parseColor("#2E9E5B")
val GREY = Color.parseColor("#8A94A0")
const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

fun Context.label(t: String, size: Float = 16f, color: Int = Color.WHITE) =
    TextView(this).apply { text = t; textSize = size; setTextColor(color) }

fun Context.btn(t: String, bg: Int = BLUE, onClick: () -> Unit) = Button(this).apply {
    text = t
    setTextColor(Color.WHITE)
    isAllCaps = false
    background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(12).toFloat() }
    setOnClickListener { onClick() }
}

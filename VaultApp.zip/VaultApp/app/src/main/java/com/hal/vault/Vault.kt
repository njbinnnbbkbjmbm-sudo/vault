package com.hal.vault

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import android.util.Size
import java.io.ByteArrayOutputStream
import java.util.UUID

class Media(
    val uri: Uri, val name: String, val mime: String, val rel: String,
    val size: Long, val taken: Long, val video: Boolean
)

object Vault {

    /** نسخ مشفّر إلى الخزنة. لا يُحذف الأصل هنا؛ الحذف يتم بعد نجاح النسخ وبموافقة النظام. */
    fun hide(ctx: Context, m: Media): Boolean {
        val id = UUID.randomUUID().toString()
        val enc = Store.file(ctx, id)
        return try {
            val n = ctx.contentResolver.openInputStream(m.uri)!!.use { Crypto.encrypt(ctx, it, enc) }
            if (m.size > 0 && n != m.size) { enc.delete(); return false }
            try {
                val bmp = ctx.contentResolver.loadThumbnail(m.uri, Size(256, 256), null)
                val bo = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 80, bo)
                Crypto.encryptBytes(ctx, bo.toByteArray(), Store.thumb(ctx, id))
            } catch (_: Exception) {}
            Store.add(ctx, Item(id, m.name, m.mime, m.rel, n, m.taken, System.currentTimeMillis()))
            true
        } catch (e: Exception) {
            enc.delete()
            false
        }
    }

    /** إرجاع الملف إلى مجلده الأصلي (نفس الاسم والمسار وتاريخ التصوير). */
    fun restore(ctx: Context, item: Item): Boolean {
        val r = ctx.contentResolver
        val col = if (item.isVideo) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        else MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val fallback = if (item.isVideo) "Movies/Restored/" else "Pictures/Restored/"

        fun ins(rel: String): Uri? = r.insert(col, ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, item.name)
            put(MediaStore.MediaColumns.MIME_TYPE, item.mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
            if (item.dateTaken > 0) put(MediaStore.MediaColumns.DATE_TAKEN, item.dateTaken)
        })

        var uri: Uri? = if (item.relPath.isBlank()) null else try { ins(item.relPath) } catch (e: Exception) { null }
        if (uri == null) uri = try { ins(fallback) } catch (e: Exception) { null }
        if (uri == null) return false

        return try {
            r.openOutputStream(uri)!!.use { out -> Crypto.decrypt(ctx, Store.file(ctx, item.id), out) }
            r.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            Store.drop(ctx, item)
            true
        } catch (e: Exception) {
            try { r.delete(uri, null, null) } catch (_: Exception) {}
            false
        }
    }
}

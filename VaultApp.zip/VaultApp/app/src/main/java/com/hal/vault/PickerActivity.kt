package com.hal.vault

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class PickerActivity : BaseActivity() {
    private lateinit var grid: Grid
    private lateinit var go: Button
    private var media = listOf<Media>()

    private val delLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        toast(
            if (r.resultCode == RESULT_OK) "تم الإخفاء وحُذفت النسخ الأصلية من المعرض ✓"
            else "نُسخت إلى الخزنة، لكن لم تُحذف الأصلية من المعرض (احذفها يدوياً)"
        )
        finish()
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { g ->
        if (g.values.all { it }) load() else { toast("يلزم السماح بالوصول إلى الصور والفيديو"); finish() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        grid = Grid(this, { toggle(it) }, { toggle(it) })
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        top.addView(label("اختر ما تريد إخفاءه", 20f), LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(label("تحديد الكل", 15f, BLUE).apply {
            setOnClickListener {
                grid.sel.clear(); grid.sel.addAll(media.map { it.uri.toString() })
                grid.notifyDataSetChanged(); upd()
            }
        })
        root.addView(top)
        val rv = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@PickerActivity, 3)
            adapter = grid
        }
        root.addView(rv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        go = btn("إخفاء المحدد (0)", GREEN) { hide() }
        root.addView(go, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(12), dp(8), dp(12), dp(12)) })
        setContentView(root)
        upd()

        val need = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (need.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) load()
        else permLauncher.launch(need)
    }

    private fun toggle(c: Cell) {
        if (!grid.sel.add(c.key)) grid.sel.remove(c.key)
        grid.notifyDataSetChanged(); upd()
    }

    private fun upd() {
        go.text = "إخفاء المحدد (${grid.sel.size})"
        go.isEnabled = grid.sel.isNotEmpty()
    }

    private fun load() {
        Thread {
            val l = queryMedia()
            runOnUiThread {
                media = l
                grid.set(l.map { m ->
                    Cell(m.uri.toString(), m.video) { contentResolver.loadThumbnail(m.uri, Size(256, 256), null) }
                })
            }
        }.start()
    }

    private fun queryMedia(): List<Media> {
        val out = ArrayList<Media>()
        for (video in listOf(false, true)) {
            val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val p = arrayOf(
                MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.RELATIVE_PATH,
                MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DATE_ADDED
            )
            contentResolver.query(base, p, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val taken = c.getLong(5).takeIf { it > 0 } ?: (c.getLong(6) * 1000)
                    out.add(
                        Media(
                            ContentUris.withAppendedId(base, c.getLong(0)),
                            c.getString(1) ?: "file",
                            c.getString(2) ?: (if (video) "video/mp4" else "image/jpeg"),
                            c.getString(3) ?: "", c.getLong(4), taken, video
                        )
                    )
                }
            }
        }
        return out.sortedByDescending { it.taken }
    }

    private fun hide() {
        val chosen = media.filter { it.uri.toString() in grid.sel }
        val d = AlertDialog.Builder(this).setMessage("جارٍ النسخ المشفّر…").setCancelable(false).show()
        Thread {
            val done = chosen.filter { Vault.hide(this, it) }
            runOnUiThread {
                d.dismiss()
                if (done.isEmpty()) {
                    toast("تعذّر النقل إلى الخزنة")
                } else {
                    try {
                        val pi = MediaStore.createDeleteRequest(contentResolver, done.map { it.uri })
                        delLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                    } catch (e: Exception) {
                        toast("نُسخت إلى الخزنة لكن تعذّر حذف الأصلية"); finish()
                    }
                }
            }
        }.start()
    }
}

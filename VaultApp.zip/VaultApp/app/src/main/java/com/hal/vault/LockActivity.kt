package com.hal.vault

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class LockActivity : BaseActivity() {
    override val needsUnlock = false

    private var first: String? = null
    private lateinit var title: TextView
    private lateinit var err: TextView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(BG)
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        root.addView(label("🔒", 56f).apply { gravity = Gravity.CENTER })
        title = label(if (Pin.isSet(this)) "أدخل الرمز السري" else "أنشئ رمزاً سرياً (4 أرقام على الأقل)", 20f)
            .apply { gravity = Gravity.CENTER }
        root.addView(title, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(16) })

        input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            gravity = Gravity.CENTER
            textSize = 28f
            setTextColor(Color.WHITE)
            filters = arrayOf(InputFilter.LengthFilter(10))
            imeOptions = EditorInfo.IME_ACTION_DONE
            setOnEditorActionListener { _, _, _ -> submit(); true }
        }
        root.addView(input, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(16) })

        err = label("", 14f, Color.parseColor("#FF8A80")).apply { gravity = Gravity.CENTER }
        root.addView(err, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        root.addView(btn("متابعة") { submit() }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(16) })

        if (Pin.isSet(this) && canBio()) {
            root.addView(btn("استخدام البصمة", Color.parseColor("#2B3440")) { bioPrompt() },
                LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
            if (savedInstanceState == null) bioPrompt()
        }
        setContentView(root)
    }

    private fun canBio() = BiometricManager.from(this)
        .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS

    private fun bioPrompt() {
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("فتح الخزنة")
            .setNegativeButtonText("استخدم الرمز")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()
        BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { open() }
            }).authenticate(info)
    }

    private fun submit() {
        val pin = input.text.toString()
        input.setText("")
        if (!Pin.isSet(this)) {
            if (pin.length < 4) { err.text = "الرمز يجب أن يكون 4 أرقام على الأقل"; return }
            val f = first
            if (f == null) {
                first = pin; title.text = "أعد إدخال الرمز للتأكيد"; err.text = ""
            } else if (f == pin) {
                Pin.set(this, pin); open()
            } else {
                first = null; title.text = "أنشئ رمزاً سرياً (4 أرقام على الأقل)"; err.text = "الرمزان غير متطابقين"
            }
        } else {
            val wait = Pin.waitMs(this)
            if (wait > 0) { err.text = "محاولات كثيرة. حاول بعد ${wait / 1000 + 1} ثانية"; return }
            if (Pin.check(this, pin)) open() else { Pin.fail(this); err.text = "رمز خاطئ" }
        }
    }

    private fun open() {
        App.unlocked = true
        startActivity(Intent(this, VaultActivity::class.java))
        finish()
    }
}

package com.hal.vault

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class Cell(val key: String, val video: Boolean, val bmp: () -> Bitmap?)

class Square(c: Context) : FrameLayout(c) {
    override fun onMeasure(w: Int, h: Int) { super.onMeasure(w, w) }
}

class Grid(
    private val ctx: Context,
    private val onTap: (Cell) -> Unit,
    private val onHold: (Cell) -> Unit
) : RecyclerView.Adapter<Grid.VH>() {

    class VH(val root: Square, val img: ImageView, val play: TextView, val tick: TextView) :
        RecyclerView.ViewHolder(root)

    private var cells: List<Cell> = emptyList()
    val sel = LinkedHashSet<String>()
    private val pool = Executors.newFixedThreadPool(3)
    private val ui = Handler(Looper.getMainLooper())
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    fun set(list: List<Cell>) { cells = list; notifyDataSetChanged() }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
        val r = Square(ctx).apply {
            setPadding(ctx.dp(1), ctx.dp(1), ctx.dp(1), ctx.dp(1))
            layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
        }
        val img = ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(CARD) }
        val play = TextView(ctx).apply {
            text = "▶"; setTextColor(Color.WHITE); textSize = 14f
            setPadding(ctx.dp(6), 0, 0, ctx.dp(4))
        }
        val tick = TextView(ctx).apply {
            text = "✓"; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(GREEN) }
            visibility = View.GONE
        }
        r.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
        r.addView(play, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START))
        r.addView(tick, FrameLayout.LayoutParams(ctx.dp(24), ctx.dp(24), Gravity.TOP or Gravity.END).apply {
            setMargins(ctx.dp(6), ctx.dp(6), ctx.dp(6), ctx.dp(6))
        })
        return VH(r, img, play, tick)
    }

    override fun onBindViewHolder(h: VH, i: Int) {
        val c = cells[i]
        h.img.tag = c.key
        val hit = cache.get(c.key)
        if (hit != null) h.img.setImageBitmap(hit) else {
            h.img.setImageDrawable(null)
            pool.execute {
                val b = try { c.bmp() } catch (e: Exception) { null }
                if (b != null) {
                    cache.put(c.key, b)
                    ui.post { if (h.img.tag == c.key) h.img.setImageBitmap(b) }
                }
            }
        }
        h.play.visibility = if (c.video) View.VISIBLE else View.GONE
        val s = c.key in sel
        h.tick.visibility = if (s) View.VISIBLE else View.GONE
        h.img.alpha = if (s) 0.55f else 1f
        h.root.setOnClickListener { onTap(c) }
        h.root.setOnLongClickListener { onHold(c); true }
    }

    override fun getItemCount() = cells.size
}

package com.hal.vault

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.*
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** تشفير AES-256 للملفات. المفتاح الرئيسي محمي داخل Android Keystore. */
object Crypto {
    private const val ALIAS = "vault_wrap_key"
    private var fileKey: SecretKeySpec? = null

    private fun wrapKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return kg.generateKey()
    }

    @Synchronized
    fun key(ctx: Context): SecretKeySpec {
        fileKey?.let { return it }
        val p = ctx.getSharedPreferences("vault_sec", Context.MODE_PRIVATE)
        val stored = p.getString("mk", null)
        val raw: ByteArray
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        if (stored == null) {
            raw = ByteArray(32).also { SecureRandom().nextBytes(it) }
            c.init(Cipher.ENCRYPT_MODE, wrapKey())
            val enc = c.iv + c.doFinal(raw)
            p.edit().putString("mk", Base64.encodeToString(enc, Base64.NO_WRAP)).apply()
        } else {
            val enc = Base64.decode(stored, Base64.NO_WRAP)
            c.init(Cipher.DECRYPT_MODE, wrapKey(), GCMParameterSpec(128, enc.copyOfRange(0, 12)))
            raw = c.doFinal(enc.copyOfRange(12, enc.size))
        }
        return SecretKeySpec(raw, "AES").also { fileKey = it }
    }

    fun encrypt(ctx: Context, input: InputStream, dest: File): Long {
        val iv = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/CTR/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(ctx), IvParameterSpec(iv))
        var total = 0L
        FileOutputStream(dest).use { out ->
            out.write(iv)
            val buf = ByteArray(65536)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                total += n
                c.update(buf, 0, n)?.let { out.write(it) }
            }
            out.write(c.doFinal())
        }
        return total
    }

    fun encryptBytes(ctx: Context, data: ByteArray, dest: File) { encrypt(ctx, ByteArrayInputStream(data), dest) }

    fun decrypt(ctx: Context, src: File, out: OutputStream) {
        FileInputStream(src).use { inp ->
            val iv = ByteArray(16)
            var r = 0
            while (r < 16) {
                val n = inp.read(iv, r, 16 - r)
                if (n < 0) throw IOException("bad file")
                r += n
            }
            val c = Cipher.getInstance("AES/CTR/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(ctx), IvParameterSpec(iv))
            val buf = ByteArray(65536)
            while (true) {
                val n = inp.read(buf)
                if (n < 0) break
                c.update(buf, 0, n)?.let { out.write(it) }
            }
            out.write(c.doFinal())
        }
    }

    fun decryptBytes(ctx: Context, src: File): ByteArray {
        val b = ByteArrayOutputStream()
        decrypt(ctx, src, b)
        return b.toByteArray()
    }
}

/** الرمز السري: مُجزّأ بـ PBKDF2 مع قفل مؤقت بعد المحاولات الخاطئة. */
object Pin {
    private fun p(c: Context) = c.getSharedPreferences("vault_pin", Context.MODE_PRIVATE)

    private fun hash(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)).encoded

    fun isSet(c: Context) = p(c).contains("h")

    fun set(c: Context, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p(c).edit()
            .putString("s", Base64.encodeToString(salt, 0))
            .putString("h", Base64.encodeToString(hash(pin, salt), 0))
            .putInt("f", 0).putLong("u", 0).apply()
    }

    fun check(c: Context, pin: String): Boolean {
        val s = Base64.decode(p(c).getString("s", "") ?: "", 0)
        val h = Base64.decode(p(c).getString("h", "") ?: "", 0)
        val ok = MessageDigest.isEqual(h, hash(pin, s))
        if (ok) p(c).edit().putInt("f", 0).apply()
        return ok
    }

    fun fail(c: Context) {
        val f = p(c).getInt("f", 0) + 1
        val e = p(c).edit().putInt("f", f)
        if (f % 5 == 0) e.putLong("u", System.currentTimeMillis() + minOf(f / 5, 10) * 60_000L)
        e.apply()
    }

    fun waitMs(c: Context) = maxOf(0L, p(c).getLong("u", 0) - System.currentTimeMillis())
}

package com.hal.vault

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Item(
    val id: String,
    val name: String,
    val mime: String,
    val relPath: String,   // المكان الأصلي مثل DCIM/Camera/
    val size: Long,
    val dateTaken: Long,
    val addedAt: Long,
    var trashedAt: Long = 0L
) {
    val isVideo get() = mime.startsWith("video")

    fun json(): JSONObject = JSONObject().put("id", id).put("name", name).put("mime", mime)
        .put("rel", relPath).put("size", size).put("taken", dateTaken)
        .put("added", addedAt).put("trashed", trashedAt)

    companion object {
        fun from(o: JSONObject) = Item(
            o.getString("id"), o.getString("name"), o.getString("mime"), o.optString("rel"),
            o.optLong("size"), o.optLong("taken"), o.optLong("added"), o.optLong("trashed")
        )
    }
}

/** فهرس الملفات (مشفّر أيضاً حتى لا تظهر أسماء الملفات). */
object Store {
    private var list: MutableList<Item>? = null
    private const val TRASH_DAYS = 30L

    fun dir(c: Context) = File(c.filesDir, "vault").apply { mkdirs() }
    fun file(c: Context, id: String) = File(dir(c), "$id.enc")
    fun thumb(c: Context, id: String) = File(dir(c), "$id.th")
    private fun idx(c: Context) = File(c.filesDir, "index.dat")

    @Synchronized
    fun all(c: Context): MutableList<Item> {
        list?.let { return it }
        val l = mutableListOf<Item>()
        try {
            val f = idx(c)
            if (f.exists()) {
                val a = JSONArray(String(Crypto.decryptBytes(c, f)))
                for (i in 0 until a.length()) l.add(Item.from(a.getJSONObject(i)))
            }
        } catch (e: Exception) {
            try { idx(c).copyTo(File(c.filesDir, "index.corrupt"), true) } catch (_: Exception) {}
        }
        list = l
        val now = System.currentTimeMillis()
        val old = l.filter { it.trashedAt > 0 && now - it.trashedAt > TRASH_DAYS * 24 * 3600 * 1000 }
        if (old.isNotEmpty()) {
            old.forEach { file(c, it.id).delete(); thumb(c, it.id).delete() }
            l.removeAll(old)
            save(c)
        }
        return l
    }

    @Synchronized
    fun save(c: Context) {
        val a = JSONArray()
        all(c).forEach { a.put(it.json()) }
        val f = idx(c)
        val t = File(c.filesDir, "index.tmp")
        Crypto.encryptBytes(c, a.toString().toByteArray(), t)
        if (f.exists()) f.copyTo(File(c.filesDir, "index.bak"), true)
        t.renameTo(f)
    }

    fun get(c: Context, id: String) = all(c).firstOrNull { it.id == id }

    @Synchronized
    fun add(c: Context, item: Item) { all(c).add(item); save(c) }

    @Synchronized
    fun drop(c: Context, item: Item) {
        file(c, item.id).delete()
        thumb(c, item.id).delete()
        all(c).removeAll { it.id == item.id }
        save(c)
    }
}

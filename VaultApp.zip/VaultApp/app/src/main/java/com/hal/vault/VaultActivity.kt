package com.hal.vault

import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class VaultActivity : BaseActivity() {
    private enum class Tab(val title: String) { ALL("الكل"), PHOTOS("صور"), VIDEOS("فيديو"), TRASH("السلة") }

    private var tab = Tab.ALL
    private var shown = listOf<Item>()
    private lateinit var grid: Grid
    private lateinit var title: TextView
    private lateinit var empty: TextView
    private lateinit var tabs: LinearLayout
    private lateinit var bottom: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        grid = Grid(this, { tap(it) }, { toggle(it) })

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(8), dp(8))
        }
        title = label("خزنتي", 22f).apply { setTypeface(null, Typeface.BOLD) }
        top.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(label("⋮", 28f).apply {
            setPadding(dp(16), 0, dp(16), 0)
            setOnClickListener { showMenu(it) }
        })
        root.addView(top)
        tabs = LinearLayout(this).apply { setPadding(dp(8), 0, dp(8), dp(8)) }
        root.addView(tabs)

        val frame = FrameLayout(this)
        val rv = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@VaultActivity, 3)
            adapter = grid
        }
        empty = label("لا توجد ملفات هنا", 16f, GREY)
        frame.addView(rv, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(empty, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        root.addView(frame, LinearLayout.LayoutParams(MATCH, 0, 1f))
        bottom = LinearLayout(this).apply { setPadding(dp(8), dp(8), dp(8), dp(12)) }
        root.addView(bottom)
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (grid.sel.isNotEmpty()) { grid.sel.clear(); grid.notifyDataSetChanged(); renderBottom(); updateTitle() }
                else finish()
            }
        })
    }

    override fun onResume() {
        super.onResume()
        if (App.unlocked) refresh()
    }

    private fun thumbOf(id: String): android.graphics.Bitmap? {
        val f = Store.thumb(this, id)
        if (!f.exists()) return null
        val b = Crypto.decryptBytes(this, f)
        return BitmapFactory.decodeByteArray(b, 0, b.size)
    }

    private fun refresh() {
        shown = Store.all(this).filter {
            when (tab) {
                Tab.TRASH -> it.trashedAt > 0
                Tab.ALL -> it.trashedAt == 0L
                Tab.PHOTOS -> it.trashedAt == 0L && !it.isVideo
                Tab.VIDEOS -> it.trashedAt == 0L && it.isVideo
            }
        }.sortedByDescending { it.addedAt }
        grid.set(shown.map { i -> Cell(i.id, i.isVideo) { thumbOf(i.id) } })
        empty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        renderTabs(); renderBottom(); updateTitle()
    }

    private fun updateTitle() {
        title.text = if (grid.sel.isNotEmpty()) "${grid.sel.size} محدد"
        else "خزنتي (${Store.all(this).count { it.trashedAt == 0L }})"
    }

    private fun renderTabs() {
        tabs.removeAllViews()
        Tab.values().forEach { t ->
            val v = label(t.title, 15f, if (t == tab) Color.WHITE else GREY)
            v.setPadding(dp(14), dp(8), dp(14), dp(8))
            v.background = GradientDrawable().apply {
                setColor(if (t == tab) BLUE else CARD); cornerRadius = dp(20).toFloat()
            }
            v.setOnClickListener { tab = t; grid.sel.clear(); refresh() }
            tabs.addView(v, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
    }

    private fun addBottom(b: Button) =
        bottom.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })

    private fun renderBottom() {
        bottom.removeAllViews()
        if (grid.sel.isEmpty()) {
            if (tab != Tab.TRASH) addBottom(btn("＋ إضافة من الجهاز", GREEN) {
                startActivity(Intent(this, PickerActivity::class.java))
            })
            else bottom.addView(label("تُحذف عناصر السلة نهائياً بعد 30 يوماً", 13f, GREY))
        } else if (tab != Tab.TRASH) {
            addBottom(btn("إرجاع للمكان الأصلي", GREEN) { restoreSelected() })
            addBottom(btn("حذف", RED) { trashSelected() })
        } else {
            addBottom(btn("استعادة للخزنة") { untrashSelected() })
            addBottom(btn("حذف نهائي", RED) { purgeSelected() })
        }
    }

    private fun toggle(c: Cell) {
        if (!grid.sel.add(c.key)) grid.sel.remove(c.key)
        grid.notifyDataSetChanged(); renderBottom(); updateTitle()
    }

    private fun tap(c: Cell) {
        if (grid.sel.isNotEmpty() || tab == Tab.TRASH) toggle(c)
        else startActivity(
            Intent(this, ViewerActivity::class.java)
                .putStringArrayListExtra("ids", ArrayList(shown.map { it.id }))
                .putExtra("idx", shown.indexOfFirst { it.id == c.key })
        )
    }

    private fun work(msg: String, job: () -> String) {
        val d = AlertDialog.Builder(this).setMessage(msg).setCancelable(false).show()
        Thread {
            val r = try { job() } catch (e: Exception) { "حدث خطأ: ${e.message}" }
            runOnUiThread { d.dismiss(); toast(r); grid.sel.clear(); refresh() }
        }.start()
    }

    private fun confirm(msg: String, yes: String, action: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton(yes) { _, _ -> action() }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun restoreIds(ids: List<String>) = work("جارٍ الإرجاع إلى الأماكن الأصلية…") {
        var ok = 0
        ids.forEach { id -> Store.get(this, id)?.let { if (Vault.restore(this, it)) ok++ } }
        "أُعيد $ok من ${ids.size} إلى مكانه الأصلي"
    }

    private fun restoreSelected() = restoreIds(grid.sel.toList())

    private fun trashSelected() {
        val ids = grid.sel.toList()
        confirm("نقل ${ids.size} إلى السلة؟ تبقى 30 يوماً ثم تُحذف نهائياً.", "نقل") {
            val now = System.currentTimeMillis()
            ids.forEach { Store.get(this, it)?.trashedAt = now }
            Store.save(this); grid.sel.clear(); refresh()
        }
    }

    private fun untrashSelected() {
        grid.sel.toList().forEach { Store.get(this, it)?.trashedAt = 0L }
        Store.save(this); grid.sel.clear(); refresh()
    }

    private fun purgeIds(ids: List<String>) = work("جارٍ الحذف…") {
        ids.forEach { id -> Store.get(this, id)?.let { Store.drop(this, it) } }
        "حُذف ${ids.size} نهائياً"
    }

    private fun purgeSelected() {
        val ids = grid.sel.toList()
        confirm("حذف ${ids.size} نهائياً؟ لا يمكن التراجع.", "حذف") { purgeIds(ids) }
    }

    private fun showMenu(v: View) {
        val m = PopupMenu(this, v)
        m.menu.add(0, 1, 0, "تغيير الرمز")
        m.menu.add(0, 2, 1, "إرجاع كل الملفات")
        m.menu.add(0, 3, 2, "إفراغ السلة")
        m.menu.add(0, 4, 3, "قفل الآن")
        m.setOnMenuItemClickListener { mi ->
            when (mi.itemId) {
                1 -> changePin()
                2 -> {
                    val ids = Store.all(this).filter { it.trashedAt == 0L }.map { it.id }
                    if (ids.isNotEmpty()) confirm("إرجاع كل الملفات (${ids.size}) إلى أماكنها الأصلية؟", "إرجاع") { restoreIds(ids) }
                }
                3 -> {
                    val ids = Store.all(this).filter { it.trashedAt > 0 }.map { it.id }
                    if (ids.isNotEmpty()) confirm("إفراغ السلة نهائياً؟", "إفراغ") { purgeIds(ids) }
                }
                4 -> {
                    App.unlocked = false
                    startActivity(Intent(this, LockActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                    finish()
                }
            }
            true
        }
        m.show()
    }

    private fun changePin() {
        val e = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "الرمز الجديد (4 أرقام على الأقل)"
        }
        AlertDialog.Builder(this).setTitle("تغيير الرمز").setView(e)
            .setPositiveButton("حفظ") { _, _ ->
                val p = e.text.toString()
                if (p.length >= 4) { Pin.set(this, p); toast("تم تغيير الرمز") } else toast("الرمز قصير جداً")
            }
            .setNegativeButton("إلغاء", null).show()
    }
}

package com.hal.vault

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream

class ViewerActivity : BaseActivity() {
    private var ids = listOf<String>()
    private var idx = 0
    private var token = 0
    private lateinit var img: ImageView
    private lateinit var vid: VideoView
    private lateinit var info: TextView
    private lateinit var wait: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ids = intent.getStringArrayListExtra("ids") ?: arrayListOf()
        idx = intent.getIntExtra("idx", 0)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        img = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        vid = VideoView(this)
        MediaController(this).also { it.setAnchorView(vid); vid.setMediaController(it) }
        wait = label("جارٍ التحضير…", 16f, GREY)
        root.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(vid, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
        root.addView(wait, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#99000000"))
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        bar.addView(btn("‹") { go(-1) })
        info = label("", 14f).apply { gravity = Gravity.CENTER; maxLines = 1 }
        bar.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
        bar.addView(btn("›") { go(1) })
        root.addView(bar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))
        setContentView(root)
        show()
    }

    private fun go(d: Int) {
        val n = idx + d
        if (n in ids.indices) { idx = n; show() }
    }

    private fun rotated(bytes: ByteArray, b: Bitmap): Bitmap {
        val o = try {
            ExifInterface(ByteArrayInputStream(bytes)).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
        } catch (e: Exception) { 1 }
        val deg = when (o) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
        if (deg == 0f) return b
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg) }, true)
    }

    private fun show() {
        val t = ++token
        val item = Store.get(this, ids.getOrElse(idx) { "" }) ?: run { finish(); return }
        info.text = "${idx + 1}/${ids.size}  ${item.name}"
        vid.stopPlayback()
        vid.visibility = View.GONE
        img.visibility = View.GONE
        wait.text = "جارٍ التحضير…"
        wait.visibility = View.VISIBLE
        Thread {
            try {
                if (item.isVideo) {
                    val f = File(cacheDir, "play_${item.id}.mp4")
                    cacheDir.listFiles()?.forEach { if (it != f) it.delete() }
                    if (!f.exists()) FileOutputStream(f).use { Crypto.decrypt(this, Store.file(this, item.id), it) }
                    runOnUiThread {
                        if (t == token) {
                            wait.visibility = View.GONE
                            vid.visibility = View.VISIBLE
                            vid.setVideoPath(f.path)
                            vid.start()
                        }
                    }
                } else {
                    val bytes = Crypto.decryptBytes(this, Store.file(this, item.id))
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                    var s = 1
                    while (o.outWidth / s > 2400 || o.outHeight / s > 2400) s *= 2
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size,
                        BitmapFactory.Options().apply { inSampleSize = s })
                    val fixed = rotated(bytes, bmp)
                    runOnUiThread {
                        if (t == token) {
                            wait.visibility = View.GONE
                            img.visibility = View.VISIBLE
                            img.setImageBitmap(fixed)
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { wait.text = "تعذّر فتح الملف" }
            }
        }.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        cacheDir.listFiles()?.forEach { it.delete() }
    }
}
